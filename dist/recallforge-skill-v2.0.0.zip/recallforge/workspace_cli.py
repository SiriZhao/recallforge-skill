from __future__ import annotations

import json
from pathlib import Path

from .i18n import TerminologyMap, t
from .models import DayOverride, to_dict
from .orchestrator.calendar import mark_completed, upsert_entry
from .orchestrator.scheduler import generate_daily_plan, render_plan
from .state import course as course_mod
from .state import workspace as workspace_mod


def _num(value) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def command_workspace(args) -> None:
    """v2 commands: workspace init / add-course / list / calendar / exam /
    override / term / plan."""
    root = Path(args.dir)
    action = args.action

    if action == "init":
        try:
            state = workspace_mod.create_workspace(
                root,
                user_locale=args.locale,
                content_language=args.content_language,
                output_language=args.output_language,
                daily_total_hours=args.daily_hours,
            )
        except FileExistsError:
            state = workspace_mod.load_workspace_state(root)
            print(t(state.user_locale, "workspace.init.exists", path=str(root)))
            return
        print(t(state.user_locale, "workspace.init.ok", path=str(root)))
        print(
            t(
                state.user_locale,
                "workspace.init.locale",
                ui_locale=state.user_locale,
                content_language=state.content_language,
                output_language=state.output_language,
            )
        )
        return

    if action == "add-course":
        state = workspace_mod.load_workspace_state(root)
        locale = state.user_locale
        localized: dict[str, str] = {}
        if getattr(args, "name_zh", None):
            localized["zh-CN"] = args.name_zh
        if getattr(args, "name_en", None):
            localized["en-US"] = args.name_en
        source_languages = getattr(args, "source_language", None) or []
        try:
            workspace_mod.add_course_to_workspace(
                root,
                course_id=args.course,
                course_name=args.name,
                course_name_localized=localized or None,
                source_languages=source_languages or None,
                exam_date=args.exam_date,
                exam_time=args.exam_time,
                target_score=args.target_score,
                current_estimated_score=args.estimated_score,
                daily_preference=args.daily_preference,
                importance_override=args.importance,
                status=args.status,
            )
        except (ValueError, FileExistsError) as exc:
            print(f"error: {exc}")
            return
        if args.exam_date:
            calendar = workspace_mod.load_exam_calendar(root)
            upsert_entry(
                calendar,
                course_id=args.course,
                exam_date=args.exam_date,
                exam_time=args.exam_time,
            )
            workspace_mod.save_exam_calendar(root, calendar)
        print(t(locale, "workspace.course.added", course_id=args.course, name=args.name))
        return

    if action == "list":
        state = workspace_mod.load_workspace_state(root)
        locale = state.user_locale
        print(
            t(
                locale,
                "workspace.list.title",
                workspace_id=state.workspace_id,
                ui_locale=locale,
                hours=_num(state.daily_total_hours),
            )
        )
        courses = workspace_mod.list_courses(root)
        if not courses:
            print(t(locale, "workspace.list.empty"))
            return
        for cid in courses:
            manifest = course_mod.load_manifest(course_mod.course_dir(root, cid))
            if manifest.exam_date:
                print(
                    t(
                        locale,
                        "workspace.list.course",
                        course_id=cid,
                        name=manifest.course_name,
                        exam_date=manifest.exam_date,
                        target=manifest.target_score,
                    )
                )
            else:
                print(
                    t(
                        locale,
                        "workspace.list.course.no_exam",
                        course_id=cid,
                        name=manifest.course_name,
                        target=manifest.target_score,
                    )
                )
        return

    if action == "calendar":
        state = workspace_mod.load_workspace_state(root)
        locale = state.user_locale
        calendar = workspace_mod.load_exam_calendar(root)
        print(t(locale, "workspace.calendar.title", workspace_id=state.workspace_id))
        if not calendar.entries:
            print(t(locale, "workspace.calendar.empty"))
            return
        for entry in calendar.entries:
            date_label = entry.exam_date or t(locale, "course.exam.unknown")
            if entry.exam_date:
                print(
                    t(
                        locale,
                        "workspace.calendar.entry",
                        course_id=entry.course_id,
                        date_label=date_label,
                        time_label=entry.exam_time or "",
                        status=t(locale, f"cal.status.{entry.status}"),
                        weight=_num(entry.weight),
                    )
                )
            else:
                print(
                    t(
                        locale,
                        "workspace.calendar.entry.no_date",
                        course_id=entry.course_id,
                        status=t(locale, f"cal.status.{entry.status}"),
                    )
                )
        return

    if action == "exam":
        state = workspace_mod.load_workspace_state(root)
        locale = state.user_locale
        calendar = workspace_mod.load_exam_calendar(root)
        if args.mark == "completed":
            mark_completed(calendar, args.course)
            date_label = t(locale, "course.exam.unknown")
        else:
            upsert_entry(
                calendar,
                course_id=args.course,
                exam_date=args.date,
                exam_time=args.time,
            )
            date_label = args.date or t(locale, "course.exam.unknown")
        workspace_mod.save_exam_calendar(root, calendar)
        print(
            t(
                locale,
                "workspace.exam.updated",
                course_id=args.course,
                date_label=date_label,
                time_label=args.time or "",
                status=t(locale, f"cal.status.{args.mark}"),
            )
        )
        return

    if action == "override":
        state = workspace_mod.load_workspace_state(root)
        locale = state.user_locale
        course_hours: dict[str, float] = {}
        for pair in getattr(args, "course_hours", None) or []:
            cid, hours = pair.split(":", 1)
            course_hours[cid] = float(hours)
        targets: dict[str, int] = {}
        for pair in getattr(args, "target", None) or []:
            cid, score = pair.split(":", 1)
            targets[cid] = int(score)
        date_changes: dict[str, str] = {}
        for pair in getattr(args, "exam_date", None) or []:
            cid, value = pair.split(":", 1)
            date_changes[cid] = value
        override = DayOverride(
            date=args.date,
            skip_courses=getattr(args, "skip", None) or [],
            total_hours=args.hours,
            course_hours=course_hours,
            target_scores=targets,
            exam_date_changes=date_changes,
            note=args.note,
        )
        workspace_mod.upsert_override(root, override)
        print(t(locale, "workspace.override.saved", date=args.date))
        print(
            t(
                locale,
                "workspace.override.detail",
                skip=", ".join(override.skip_courses) or t(locale, "common.none"),
                hours=_num(override.total_hours) if override.total_hours is not None else t(locale, "common.none"),
                course_hours=", ".join(f"{k}:{v}" for k, v in course_hours.items()) or t(locale, "common.none"),
                targets=", ".join(f"{k}:{v}" for k, v in targets.items()) or t(locale, "common.none"),
            )
        )
        return

    if action == "term":
        state = workspace_mod.load_workspace_state(root)
        locale = state.user_locale
        course_path = course_mod.course_dir(root, args.course)
        data = course_mod.load_course_json(course_path, "terminology_map.json", {}) or {}
        term_map = TerminologyMap.from_state(data)
        term_map.add(
            args.key,
            zh=args.zh,
            en=args.en,
            aliases=getattr(args, "alias", None),
        )
        course_mod._write_json(course_path / "terminology_map.json", term_map.to_state())
        print(
            t(
                locale,
                "workspace.term.added",
                course_id=args.course,
                term_key=args.key,
                zh=args.zh or "",
                en=args.en or "",
            )
        )
        return

    if action == "plan":
        state = workspace_mod.load_workspace_state(root)
        locale = state.user_locale
        plan = generate_daily_plan(
            root,
            args.date,
            total_hours_override=args.hours,
            skip_courses=getattr(args, "skip", None) or None,
        )
        print(render_plan(plan, locale))
        if args.json:
            print(json.dumps(to_dict(plan), ensure_ascii=False, indent=2))
        return

    if action == "ingest":
        from .ingestion.pipeline import ingest_directory, ingest_file
        from .ingestion.types import IngestOptions
        from .state.isolation import StateContaminationError

        options = IngestOptions(
            provider_name=args.provider or "",
            allow_ocr_fallback=args.ocr,
            offline_mode=args.offline,
            store_mode="demo" if args.demo else "real",
        )
        input_path = Path(args.input)
        try:
            if input_path.is_dir():
                result = ingest_directory(root, args.course, input_path, options=options)
            else:
                result = ingest_file(root, args.course, input_path, options=options)
        except StateContaminationError as exc:
            print(f"error: real state rejected synthetic/mock content: {exc}")
            return
        print(f"documents seen: {len(result.documents_seen)}")
        print(f"documents parsed: {len(result.documents_parsed)}")
        print(f"evidence added: {len(result.evidence_added)}")
        print(f"evidence duplicates: {result.evidence_duplicates}")
        print(f"unresolved pages: {len(result.unresolved_pages)}")
        for page in result.unresolved_pages:
            print(f"  unresolved: {page}")
        for warning in result.warnings:
            print(f"  warn: {warning}")
        return

    if action == "build":
        from .knowledge.build import build_course_intelligence

        try:
            result = build_course_intelligence(
                root,
                args.course,
                days_to_exam=args.days_to_exam,
            )
        except FileNotFoundError as exc:
            print(f"error: {exc}")
            return
        print(f"topics: {len(result.topics)}")
        print(f"exam points: {len(result.exam_points)}")
        print(f"past exam sets: {len(result.past_exam_sets)}")
        print(f"past exam questions: {sum(len(s.questions) for s in result.past_exam_sets)}")
        print(f"conflicts detected: {len(result.conflicts)}")
        print(f"coverage verdict: {result.coverage.verdict}")
        print("risk radar:")
        for point in result.exam_points:
            print(
                f"  [{point.priority}] {point.topic_name} "
                f"(likelihood={point.likelihood_estimate:.2f}, freq={point.past_exam_frequency}, "
                f"teacher={point.teacher_emphasis})"
            )
        return

    if action == "diagnostic":
        from .knowledge.build import build_course_intelligence
        from .student.diagnostic import build_diagnostic_plan
        from .student.store import load_student_model

        try:
            build_result = build_course_intelligence(root, args.course, persist=False)
        except FileNotFoundError as exc:
            print(f"error: {exc}")
            return
        model = load_student_model(root, args.course)
        plan = build_diagnostic_plan(
            args.course,
            build_result.topics,
            model,
            minutes=args.minutes,
            locale=workspace_mod.load_workspace_state(root).user_locale,
        )
        print(f"diagnostic: ~{plan.estimated_minutes} minutes, {len(plan.items)} items")
        for item in plan.items:
            print(f"  - {item.topic_name} ({item.question_type}) : {item.reason}")
        return

    if action == "answer":
        from .student.sessions import AnswerResult, record_answer, record_wrongbook_entry
        from .student.store import load_student_model, save_student_model

        model = load_student_model(root, args.course)
        result = AnswerResult(
            topic_id=args.topic,
            correct=args.correct,
            difficulty=args.difficulty,
            used_hint=args.hint,
            mistake_type=args.mistake_type,
            question_type=args.question_type,
            is_new_form=args.new_form,
        )
        record_answer(model, result)
        if not args.correct:
            entry = record_wrongbook_entry(
                model,
                result,
                question_text=args.question or "(self-reported wrong answer)",
                correct_answer=args.correct_answer or "",
                user_answer=args.user_answer or "",
            )
            # persist to wrongbook.json (only real wrong answers)
            from .state.course import load_course_json

            course_path = course_mod.course_dir(root, args.course)
            wrongbook = load_course_json(course_path, "wrongbook.json", {}) or {}
            entries = wrongbook.get("entries", []) or []
            entries.append(entry)
            wrongbook["entries"] = entries
            course_mod._write_json(course_path / "wrongbook.json", wrongbook)
            print(f"wrongbook entry recorded for topic {args.topic}")
        save_student_model(root, args.course, model)
        tm = model.topics[args.topic]
        print(f"topic {args.topic}: mastery={tm.mastery} score={tm.mastery_score} "
              f"attempted={tm.questions_attempted} accuracy={tm.accuracy}")
        return

    if action == "plan-v4":
        from .planner.orchestrator import generate_daily_plan_v4, render_plan_v4

        try:
            plan = generate_daily_plan_v4(
                root,
                args.date,
                total_hours_override=args.hours,
                skip_courses=getattr(args, "skip", None) or None,
            )
        except Exception as exc:
            print(f"error: {exc}")
            return
        print(render_plan_v4(plan, workspace_mod.load_workspace_state(root).user_locale))
        if args.json:
            print(json.dumps(to_dict(plan), ensure_ascii=False, indent=2))
        return

    if action == "replan":
        from .planner.events import record_replan_event
        from .models import ReplanEvent

        event = ReplanEvent(
            event_type=args.event_type,
            course_id=args.course,
            detail={
                "new_date": args.new_date,
                "target_score": args.target_score,
                "daily_total_hours": args.hours,
            },
        )
        record_replan_event(root, event)
        print(f"replan event recorded: {args.event_type}")
        return

    if action == "nl":
        from .planner.nl import parse_command

        command = parse_command(args.text)
        print(f"parsed: action={command.action} course={command.course_id} value={command.value}")
        return

    if action == "tutor":
        from .knowledge.build import build_course_intelligence
        from .student.store import load_student_model
        from .tutor.tutor import build_tutor_response

        try:
            result = build_course_intelligence(root, args.course, persist=False)
        except FileNotFoundError as exc:
            print(f"error: {exc}")
            return
        topic = next((t for t in result.topics if t.topic_id == args.topic), None)
        if topic is None:
            print(f"error: topic {args.topic!r} not found")
            return
        model = load_student_model(root, args.course)
        locale = workspace_mod.load_workspace_state(root).user_locale
        response = build_tutor_response(topic, model, locale=locale)
        print(f"## {response.topic_name}")
        for section in response.sections:
            print(f"\n### {section.title}" + (" [Supplementary]" if section.supplementary else ""))
            print(section.content)
        if response.check_question:
            print(f"\n**{response.check_question}**")
        return

    if action == "quiz":
        from .knowledge.build import build_course_intelligence
        from .student.store import load_student_model
        from .tutor.quiz import generate_quiz

        try:
            result = build_course_intelligence(root, args.course, persist=False)
        except FileNotFoundError as exc:
            print(f"error: {exc}")
            return
        model = load_student_model(root, args.course)
        wrongbook = course_mod.load_course_json(
            course_mod.course_dir(root, args.course), "wrongbook.json", {}
        ) or {}
        questions = generate_quiz(
            topics=result.topics,
            exam_points=result.exam_points,
            past_exam_sets=result.past_exam_sets,
            student=model,
            wrongbook_entries=wrongbook.get("entries", []),
            mode=args.mode,
            count=args.count,
            question_language=args.question_language,
            explanation_language=args.explanation_language,
        )
        for q in questions:
            print(f"[{q.question_id}] L{q.level} {q.question_type} | {q.topic_name}")
            print(f"  {q.question_text}")
            if q.options:
                for option in q.options:
                    print(f"    {option}")
            if q.derived_from:
                print(f"  (derived_from: {q.derived_from}, variation: {q.variation_type})")
            print(f"  答: {q.correct_answer}")
            print(f"  讲: {q.explanation}")
        return

    if action == "cram":
        from .knowledge.build import build_course_intelligence
        from .student.store import load_student_model
        from .tutor.cram import build_cram_plan, render_cram_plan

        try:
            result = build_course_intelligence(root, args.course, persist=False)
        except FileNotFoundError as exc:
            print(f"error: {exc}")
            return
        model = load_student_model(root, args.course)
        wrongbook = course_mod.load_course_json(
            course_mod.course_dir(root, args.course), "wrongbook.json", {}
        ) or {}
        locale = workspace_mod.load_workspace_state(root).user_locale
        plan = build_cram_plan(
            workspace_root=root,
            course_id=args.course,
            topics=result.topics,
            exam_points=result.exam_points,
            student=model,
            wrongbook_entries=wrongbook.get("entries", []),
            mode=args.mode,
            locale=locale,
        )
        print(render_cram_plan(plan, locale))
        return

    if action == "material-report":
        from .reporting.welcome import build_first_use_report
        from .knowledge.build import build_course_intelligence
        from .student.store import load_student_model
        from .state import course as course_mod

        try:
            result = build_course_intelligence(root, args.course, persist=False)
        except FileNotFoundError as exc:
            print(f"error: {exc}")
            return
        records = course_mod.load_course_json(
            course_mod.course_dir(root, args.course), "evidence_store.json", {}
        ) or {}
        model = load_student_model(root, args.course)
        locale = workspace_mod.load_workspace_state(root).user_locale
        text = build_first_use_report(
            root,
            args.course,
            topics=result.topics,
            student=model,
            coverage=result.coverage,
            evidence_records=records.get("records", []),
            unresolved_pages=result.coverage.unresolved_documents,
            locale=locale,
            output_mode=getattr(args, "output_mode", "bilingual"),
        )
        print(text)
        return

    if action == "dashboard":
        from .reporting.dashboard import build_dashboard
        from .planner.orchestrator import generate_daily_plan_v4

        try:
            plan = generate_daily_plan_v4(root, args.date)
        except Exception:
            plan = None
        locale = workspace_mod.load_workspace_state(root).user_locale
        print(build_dashboard(root, plan=plan, plan_date=args.date, locale=locale))
        return

    if action == "report":
        from .reporting.reports import render_report
        from .reporting.export import export_report

        locale = workspace_mod.load_workspace_state(root).user_locale
        try:
            text = render_report(
                root,
                args.type,
                course_id=args.course,
                locale=locale,
                output_mode=getattr(args, "output_mode", "bilingual"),
            )
        except (ValueError, FileNotFoundError) as exc:
            print(f"error: {exc}")
            return
        print(text)
        if args.out:
            ok, message = export_report(
                text,
                output_path=args.out,
                fmt=args.format,
                locale=locale,
            )
            print(message)
        return

    raise SystemExit(f"unknown workspace action: {action}")


def add_workspace_parser(subparsers) -> None:
    """Register the v2 'workspace' command tree on the top-level subparsers."""
    ws = subparsers.add_parser("workspace", help="v2 multi-course workspace management")
    ws_sub = ws.add_subparsers(dest="action", required=True)

    init = ws_sub.add_parser("init", help="create a new exam-week workspace")
    init.add_argument("--dir", required=True)
    init.add_argument("--locale", default="zh-CN", choices=["zh-CN", "en-US"])
    init.add_argument("--content-language", default="auto")
    init.add_argument("--output-language", default=None)
    init.add_argument("--daily-hours", type=float, default=6.0)
    init.set_defaults(func=command_workspace)

    add = ws_sub.add_parser("add-course", help="add a course with its isolated state")
    add.add_argument("--dir", required=True)
    add.add_argument("--course", required=True, help="stable id, e.g. organic-chemistry")
    add.add_argument("--name", required=True)
    add.add_argument("--name-zh", default=None)
    add.add_argument("--name-en", default=None)
    add.add_argument("--source-language", action="append", default=None)
    add.add_argument("--exam-date", default=None)
    add.add_argument("--exam-time", default=None)
    add.add_argument("--target-score", type=int, default=80)
    add.add_argument("--estimated-score", type=int, default=None)
    add.add_argument("--daily-preference", type=float, default=1.0)
    add.add_argument("--importance", type=float, default=None)
    add.add_argument("--status", default="active")
    add.set_defaults(func=command_workspace)

    list_ = ws_sub.add_parser("list", help="list courses in the workspace")
    list_.add_argument("--dir", required=True)
    list_.set_defaults(func=command_workspace)

    cal = ws_sub.add_parser("calendar", help="show the global exam calendar")
    cal.add_argument("--dir", required=True)
    cal.set_defaults(func=command_workspace)

    exam = ws_sub.add_parser("exam", help="set or update a course exam")
    exam.add_argument("--dir", required=True)
    exam.add_argument("--course", required=True)
    exam.add_argument("--date", default=None)
    exam.add_argument("--time", default=None)
    exam.add_argument("--mark", choices=["scheduled", "completed", "canceled"], default="scheduled")
    exam.set_defaults(func=command_workspace)

    override = ws_sub.add_parser("override", help="store a per-date user override")
    override.add_argument("--dir", required=True)
    override.add_argument("--date", required=True)
    override.add_argument("--skip", action="append", default=None)
    override.add_argument("--hours", type=float, default=None)
    override.add_argument("--course-hours", action="append", default=None, help="course:hours")
    override.add_argument("--target", action="append", default=None, help="course:score")
    override.add_argument("--exam-date", action="append", default=None, help="course:new-date")
    override.add_argument("--note", default=None)
    override.set_defaults(func=command_workspace)

    term = ws_sub.add_parser("term", help="add a terminology entry to a course")
    term.add_argument("--dir", required=True)
    term.add_argument("--course", required=True)
    term.add_argument("--key", required=True)
    term.add_argument("--zh", default=None)
    term.add_argument("--en", default=None)
    term.add_argument("--alias", action="append", default=None)
    term.set_defaults(func=command_workspace)

    plan = ws_sub.add_parser("plan", help="generate the global daily study plan")
    plan.add_argument("--dir", required=True)
    plan.add_argument("--date", default=None)
    plan.add_argument("--hours", type=float, default=None)
    plan.add_argument("--skip", action="append", default=None)
    plan.add_argument("--json", action="store_true")
    plan.set_defaults(func=command_workspace)

    ingest = ws_sub.add_parser("ingest", help="ingest materials into a course (native multimodal first)")
    ingest.add_argument("--dir", required=True)
    ingest.add_argument("--course", required=True)
    ingest.add_argument("--input", required=True, help="file or directory to ingest")
    ingest.add_argument("--provider", default=None, help="multimodal provider name (openai|deepseek|synthetic)")
    ingest.add_argument("--ocr", action="store_true", help="allow local OCR fallback (disabled by default)")
    ingest.add_argument("--offline", action="store_true", help="explicit offline mode")
    ingest.add_argument("--demo", action="store_true", help="demo mode: allow synthetic records")
    ingest.set_defaults(func=command_workspace)

    build = ws_sub.add_parser("build", help="build course knowledge + exam intelligence from evidence")
    build.add_argument("--dir", required=True)
    build.add_argument("--course", required=True)
    build.add_argument("--days-to-exam", type=int, default=None)
    build.set_defaults(func=command_workspace)

    diag = ws_sub.add_parser("diagnostic", help="build a 10-20 minute diagnostic test")
    diag.add_argument("--dir", required=True)
    diag.add_argument("--course", required=True)
    diag.add_argument("--minutes", type=int, default=15)
    diag.set_defaults(func=command_workspace)

    answer = ws_sub.add_parser("answer", help="record a real answer into the student model")
    answer.add_argument("--dir", required=True)
    answer.add_argument("--course", required=True)
    answer.add_argument("--topic", required=True)
    answer.add_argument("--correct", action="store_true")
    answer.add_argument("--difficulty", type=int, default=2)
    answer.add_argument("--hint", action="store_true")
    answer.add_argument("--mistake-type", default=None)
    answer.add_argument("--question-type", default="short_answer")
    answer.add_argument("--new-form", action="store_true")
    answer.add_argument("--question", default=None)
    answer.add_argument("--user-answer", default=None)
    answer.add_argument("--correct-answer", default=None)
    answer.set_defaults(func=command_workspace)

    plan4 = ws_sub.add_parser("plan-v4", help="formal exam-week daily plan (topic-level)")
    plan4.add_argument("--dir", required=True)
    plan4.add_argument("--date", default=None)
    plan4.add_argument("--hours", type=float, default=None)
    plan4.add_argument("--skip", action="append", default=None)
    plan4.add_argument("--json", action="store_true")
    plan4.set_defaults(func=command_workspace)

    replan = ws_sub.add_parser("replan", help="record a dynamic event that triggers replanning")
    replan.add_argument("--dir", required=True)
    replan.add_argument("--event-type", required=True,
                        choices=["quiz_completed", "wrong_answer", "topic_mastered", "new_material",
                                 "new_past_exam", "exam_rescheduled", "hours_changed",
                                 "target_changed", "course_completed"])
    replan.add_argument("--course", default=None)
    replan.add_argument("--new-date", default=None)
    replan.add_argument("--target-score", type=int, default=None)
    replan.add_argument("--hours", type=float, default=None)
    replan.set_defaults(func=command_workspace)

    nl = ws_sub.add_parser("nl", help="parse bilingual natural-language control (zh/en)")
    nl.add_argument("--dir", required=True)
    nl.add_argument("--text", required=True)
    nl.set_defaults(func=command_workspace)

    tutor = ws_sub.add_parser("tutor", help="tutor a topic with a course-first structured explanation")
    tutor.add_argument("--dir", required=True)
    tutor.add_argument("--course", required=True)
    tutor.add_argument("--topic", required=True)
    tutor.set_defaults(func=command_workspace)

    quiz = ws_sub.add_parser("quiz", help="generate a quiz in any mode")
    quiz.add_argument("--dir", required=True)
    quiz.add_argument("--course", required=True)
    quiz.add_argument("--mode", choices=["diagnostic", "s-priority", "weak-topic", "past-exam-style", "mixed", "wrongbook", "speed-run", "cram"], default="mixed")
    quiz.add_argument("--count", type=int, default=10)
    quiz.add_argument("--question-language", default="zh-CN")
    quiz.add_argument("--explanation-language", default=None)
    quiz.set_defaults(func=command_workspace)

    cram = ws_sub.add_parser("cram", help="build a time-constrained cram plan")
    cram.add_argument("--dir", required=True)
    cram.add_argument("--course", required=True)
    cram.add_argument("--mode", choices=["7d", "3d", "24h", "3h", "1h", "30m"], required=True)
    cram.set_defaults(func=command_workspace)

    mreport = ws_sub.add_parser("material-report", help="first-use material report after upload")
    mreport.add_argument("--dir", required=True)
    mreport.add_argument("--course", required=True)
    mreport.add_argument("--output-mode", choices=["chinese", "english", "bilingual"], default="bilingual")
    mreport.set_defaults(func=command_workspace)

    dash = ws_sub.add_parser("dashboard", help="exam-week text dashboard")
    dash.add_argument("--dir", required=True)
    dash.add_argument("--date", default=None)
    dash.set_defaults(func=command_workspace)

    report = ws_sub.add_parser("report", help="on-demand report (markdown default, optional export)")
    report.add_argument("--dir", required=True)
    report.add_argument("--type", required=True, choices=[
        "course-overview", "exam-risk-radar", "past-exam-analysis", "teacher-style",
        "formula-sheet", "wrongbook", "7-day-plan", "mock-exam",
        "1-hour-cram", "30-min-rescue", "dashboard", "welcome",
    ])
    report.add_argument("--course", default=None)
    report.add_argument("--out", default=None, help="export path")
    report.add_argument("--format", default="md", choices=["md", "docx", "pdf", "anki", "json"])
    report.add_argument("--output-mode", choices=["chinese", "english", "bilingual"], default="bilingual")
    report.set_defaults(func=command_workspace)
